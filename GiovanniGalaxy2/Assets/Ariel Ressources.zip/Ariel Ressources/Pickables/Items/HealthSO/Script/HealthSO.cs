using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "New Health", menuName = "Life/Health")]

public class HealthSO : ItemSO
{
    public float amount;
}
