using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "New Armor", menuName = "Life/Armor")]

public class ArmorSO : ItemSO
{
    public float amount;
}
